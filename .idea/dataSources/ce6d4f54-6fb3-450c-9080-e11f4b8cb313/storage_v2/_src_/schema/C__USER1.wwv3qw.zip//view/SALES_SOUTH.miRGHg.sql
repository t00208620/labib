create view SALES_SOUTH as
select s.sales_date, s.order_id, s.product_id, s.customer_id, s.sales_amount,
s.total_amount, c.region
from sales s, customer c
where s.customer_id = c.customer_id
and c.region = 'SOUTH'
/

